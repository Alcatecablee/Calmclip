// CalmClip - Extension Chunked Stream Receiver
// Injected into calmclip.video/* and localhost/*

console.log('[CalmClip Receiver] Injected')

if (location.search.includes('source=extension_stream')) {
  console.log('[CalmClip Receiver] Connecting to extension stream...')

  const port = chrome.runtime.connect({ name: 'calmclip_stream' })
  
  let mimeType = 'video/mp4'
  let fileName = 'streamed-video.mp4'

  let fileHandle = null
  let writable = null
  let writeQueue = Promise.resolve()

  port.onMessage.addListener((msg) => {
    if (msg.error) {
      console.error('[CalmClip Receiver] Stream error:', msg.error)
      window.postMessage({ type: 'CALMCLIP_STREAM_ERROR', error: msg.error }, '*')
      return
    }

    if (msg.type === 'start') {
      mimeType = msg.mimeType
      fileName = msg.name
      console.log('[CalmClip Receiver] Stream started:', fileName, mimeType)
      
      writeQueue = writeQueue.then(async () => {
        try {
          const root = await navigator.storage.getDirectory()
          fileHandle = await root.getFileHandle('calmclip-temp-stream', { create: true })
          writable = await fileHandle.createWritable()
        } catch (err) {
          console.error('[CalmClip Receiver] OPFS error:', err)
          window.postMessage({ type: 'CALMCLIP_STREAM_ERROR', error: 'Local file system access failed.' }, '*')
        }
      })
    } 
    else if (msg.type === 'chunk') {
      writeQueue = writeQueue.then(async () => {
        if (writable) {
          await writable.write(new Uint8Array(msg.data))
        }
      })
    } 
    else if (msg.type === 'end') {
      writeQueue = writeQueue.then(async () => {
        console.log('[CalmClip Receiver] Stream ended, assembling File from OPFS...')
        if (writable) {
          await writable.close()
          const file = await fileHandle.getFile()
          
          console.log(`[CalmClip Receiver] File ready: ${file.size} bytes`)
          
          const payload = { 
            type: 'CALMCLIP_BLOB_READY', 
            blob: file, 
            name: fileName 
          }
          
          // Handoff to the React app
          window.postMessage(payload, '*')
          
          // The React app may not have hydrated yet when this completes.
          // Listen for a ready ping and resend if necessary.
          window.addEventListener('message', (e) => {
            if (e.data?.type === 'CALMCLIP_APP_READY') {
              window.postMessage(payload, '*')
            }
          })
        }
      })
    }
  })

  port.onDisconnect.addListener(() => {
    console.log('[CalmClip Receiver] Port disconnected.')
  })
}
