// CalmClip - Dropbox Content Injector

console.log('[CalmClip] Dropbox injector loaded')

function injectButton() {
  if (document.getElementById('calmclip-dropbox-btn')) return

  // Dropbox UI is also SPA-heavy
  const btn = document.createElement('button')
  btn.id = 'calmclip-dropbox-btn'
  btn.textContent = 'Edit in CalmClip'
  Object.assign(btn.style, {
    position: 'fixed',
    top: '70px',
    right: '24px',
    zIndex: '9999',
    padding: '8px 16px',
    backgroundColor: '#111113',
    color: '#f2f2f2',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontFamily: 'Inter, system-ui, sans-serif'
  })

  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="23 7 16 12 23 17 23 7"></polygon>
      <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
    <span>Export to CalmClip</span>
  `

  btn.addEventListener('mouseover', () => btn.style.backgroundColor = '#202022')
  btn.addEventListener('mouseout', () => btn.style.backgroundColor = '#111113')

  btn.addEventListener('click', () => {
    btn.textContent = 'Exporting...'
    btn.style.opacity = '0.7'
    btn.style.pointerEvents = 'none'

    chrome.runtime.sendMessage({
      action: 'fetch_dropbox',
      url: location.href
    })

    setTimeout(() => {
      btn.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="23 7 16 12 23 17 23 7"></polygon>
          <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
        </svg>
        <span>Export to CalmClip</span>
      `
      btn.style.opacity = '1'
      btn.style.pointerEvents = 'auto'
    }, 3000)
  })

  document.body.appendChild(btn)
}

const observer = new MutationObserver(() => {
  // Check if it's a file view URL 
  if (location.pathname.includes('/s/') || location.pathname.includes('/scl/fi/')) {
    injectButton()
  } else {
    const btn = document.getElementById('calmclip-dropbox-btn')
    if (btn) btn.remove()
  }
})

observer.observe(document.body, { childList: true, subtree: true })
injectButton()
