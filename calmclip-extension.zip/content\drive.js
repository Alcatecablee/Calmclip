// CalmClip - Google Drive Content Injector

console.log('[CalmClip] Drive injector loaded')

function extractFileId() {
  const match = location.pathname.match(/\/file\/d\/([a-zA-Z0-9_-]+)/)
  return match ? match[1] : null
}

function injectButton() {
  if (document.getElementById('calmclip-drive-btn')) return

  const fileId = extractFileId()
  if (!fileId) return

  // We float the button because Drive's DOM is highly obfuscated and changes often.
  const btn = document.createElement('button')
  btn.id = 'calmclip-drive-btn'
  btn.textContent = 'Edit in CalmClip'
  Object.assign(btn.style, {
    position: 'fixed',
    top: '70px',
    right: '24px',
    zIndex: '9999',
    padding: '8px 16px',
    backgroundColor: '#111113',
    color: '#f2f2f2',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontFamily: 'Inter, system-ui, sans-serif'
  })

  // Add a small camera icon
  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="23 7 16 12 23 17 23 7"></polygon>
      <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
    <span>Export to CalmClip</span>
  `

  btn.addEventListener('mouseover', () => {
    btn.style.backgroundColor = '#202022'
  })
  btn.addEventListener('mouseout', () => {
    btn.style.backgroundColor = '#111113'
  })

  btn.addEventListener('click', () => {
    btn.textContent = 'Exporting...'
    btn.style.opacity = '0.7'
    btn.style.pointerEvents = 'none'

    chrome.runtime.sendMessage({
      action: 'fetch_drive',
      fileId: fileId
    })

    // Reset after a few seconds in case they want to click again later
    setTimeout(() => {
      btn.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="23 7 16 12 23 17 23 7"></polygon>
          <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
        </svg>
        <span>Export to CalmClip</span>
      `
      btn.style.opacity = '1'
      btn.style.pointerEvents = 'auto'
    }, 3000)
  })

  document.body.appendChild(btn)
}

// Drive is an SPA, so we observe mutations to re-inject if needed
const observer = new MutationObserver(() => {
  // Only inject if we are looking at a file preview
  if (location.pathname.includes('/view')) {
    injectButton()
  } else {
    const btn = document.getElementById('calmclip-drive-btn')
    if (btn) btn.remove()
  }
})

observer.observe(document.body, { childList: true, subtree: true })
injectButton()
