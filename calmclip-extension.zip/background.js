// CalmClip Extension v0 - Background Service Worker
// Registers context menu items for video/audio elements and media file links.
// On click, opens a new CalmClip tab with the source URL as a query parameter.
// The CalmClip web app handles fetching and loading the media locally.

// const CALMCLIP_BASE = 'https://calmclip.video'

// During local development, switch to localhost:
const CALMCLIP_BASE = 'http://localhost:5000'

// ---------------------------------------------------------------------------
// Context menu registration
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(() => {
  // Appears when right-clicking an HTML5 <video> or <audio> element
  chrome.contextMenus.create({
    id:       'calmclip-edit-media',
    title:    'Edit with CalmClip',
    contexts: ['video', 'audio'],
  })

  // Appears when right-clicking a direct link to a media file
  chrome.contextMenus.create({
    id:       'calmclip-edit-link',
    title:    'Edit with CalmClip',
    contexts: ['link'],
    targetUrlPatterns: [
      '*://*/*.mp4',  '*://*/*.mp4?*',
      '*://*/*.webm', '*://*/*.webm?*',
      '*://*/*.mov',  '*://*/*.mov?*',
      '*://*/*.mkv',  '*://*/*.mkv?*',
      '*://*/*.avi',  '*://*/*.avi?*',
      '*://*/*.m4v',  '*://*/*.m4v?*',
      '*://*/*.mp3',  '*://*/*.mp3?*',
      '*://*/*.wav',  '*://*/*.wav?*',
      '*://*/*.m4a',  '*://*/*.m4a?*',
      '*://*/*.ogg',  '*://*/*.ogg?*',
      '*://*/*.flac', '*://*/*.flac?*',
      '*://*/*.aac',  '*://*/*.aac?*',
    ],
  })
})

// ---------------------------------------------------------------------------
// Click handler (v0 Direct Links)
// ---------------------------------------------------------------------------

chrome.contextMenus.onClicked.addListener((info) => {
  const mediaUrl = info.srcUrl || info.linkUrl
  if (!mediaUrl) return

  // blob: and data: URLs cannot be safely passed via URL params.
  if (mediaUrl.startsWith('blob:') || mediaUrl.startsWith('data:')) {
    chrome.tabs.create({
      url: `${CALMCLIP_BASE}/?source=extension&error=${encodeURIComponent(
        'This video uses a protected stream or inline data that cannot be accessed externally. ' +
        'Try downloading the video first, then drop it into CalmClip.'
      )}`,
    })
    return
  }

  const encoded = encodeURIComponent(mediaUrl)
  chrome.tabs.create({
    url: `${CALMCLIP_BASE}/?source=extension&video=${encoded}`,
  })
})

// ---------------------------------------------------------------------------
// Phase 2: Chunked Streaming (Google Drive)
// ---------------------------------------------------------------------------

// Store pending streams by tabId so we know what to fetch when the tab connects
const pendingStreams = new Map()

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'fetch_drive' && msg.fileId) {
    chrome.tabs.create({
      url: `${CALMCLIP_BASE}/?source=extension_stream`
    }, (tab) => {
      pendingStreams.set(tab.id, {
        type: 'drive',
        fileId: msg.fileId
      })
    })
  } else if (msg.action === 'fetch_dropbox' && msg.url) {
    chrome.tabs.create({
      url: `${CALMCLIP_BASE}/?source=extension_stream`
    }, (tab) => {
      pendingStreams.set(tab.id, {
        type: 'dropbox',
        url: msg.url
      })
    })
  } else if (msg.action === 'get_capture_state') {
    sendResponse({ isRecording })
  } else if (msg.action === 'start_tab_capture') {
    handleStartCapture(msg.streamId)
  } else if (msg.action === 'stop_tab_capture') {
    handleStopCapture()
  }
})

let isRecording = false

async function handleStartCapture(streamId) {
  try {
    if (!streamId) throw new Error('No stream ID provided')
    
    await setupOffscreenDocument('offscreen.html')
    
    chrome.runtime.sendMessage({ action: 'start_recording', streamId }, (res) => {
      if (res && res.success) {
        isRecording = true
      }
    })
  } catch (err) {
    console.error('Failed to start capture:', err)
  }
}

function handleStopCapture() {
  // The offscreen document's stop_recording handler now waits for
  // MediaRecorder.onstop before calling sendResponse, so by the time
  // this callback fires, all recorded chunks are guaranteed to be
  // available for relay.
  chrome.runtime.sendMessage({ action: 'stop_recording' }, () => {
    isRecording = false
    chrome.tabs.create({ url: `${CALMCLIP_BASE}/?source=extension_stream` }, (tab) => {
      pendingStreams.set(tab.id, { type: 'tab_capture' })
    })
  })
}

async function setupOffscreenDocument(path) {
  const offscreenUrl = chrome.runtime.getURL(path)
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  })

  if (existingContexts.length > 0) return

  await chrome.offscreen.createDocument({
    url: path,
    reasons: ['USER_MEDIA'],
    justification: 'Recording the active tab'
  })
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'calmclip_stream') return

  const tabId = port.sender?.tab?.id
  if (!tabId || !pendingStreams.has(tabId)) {
    port.postMessage({ error: 'No pending stream found for this tab.' })
    port.disconnect()
    return
  }

  const job = pendingStreams.get(tabId)
  pendingStreams.delete(tabId)

  if (job.type === 'drive') {
    streamDriveFile(job.fileId, port)
  } else if (job.type === 'dropbox') {
    streamDropboxFile(job.url, port)
  } else if (job.type === 'tab_capture') {
    streamTabCapture(port)
  }
})

function streamTabCapture(port) {
  const offscreenPort = chrome.runtime.connect({ name: 'offscreen_relay' })
  
  offscreenPort.onMessage.addListener((msg) => {
    port.postMessage(msg)
    
    if (msg.type === 'end' || msg.error) {
      offscreenPort.disconnect()
      port.disconnect()
      chrome.offscreen.closeDocument()
    }
  })
}

async function streamDriveFile(fileId, port) {
  try {
    let downloadUrl = `https://drive.google.com/uc?id=${fileId}&export=download`
    let res = await fetch(downloadUrl)
    
    if (!res.ok) {
      port.postMessage({ error: `Failed to fetch from Drive: HTTP ${res.status}` })
      port.disconnect()
      return
    }

    let type = res.headers.get('content-type') || 'video/mp4'

    // Handle Google Drive's "File is too large for virus scan" warning page
    if (type.includes('text/html')) {
      const text = await res.text()
      const match = text.match(/confirm=([a-zA-Z0-9_-]+)/)
      if (match) {
        downloadUrl += `&confirm=${match[1]}`
        res = await fetch(downloadUrl)
        if (!res.ok) {
          port.postMessage({ error: `Failed to fetch confirmed Drive link: HTTP ${res.status}` })
          port.disconnect()
          return
        }
        type = res.headers.get('content-type') || 'video/mp4'
      } else {
        port.postMessage({ error: 'Google Drive returned an HTML page. Ensure you are logged in and have access to the file.' })
        port.disconnect()
        return
      }
    }

    port.postMessage({ type: 'start', mimeType: type, name: `drive-${fileId}.mp4` })

    const reader = res.body.getReader()
    
    // We send in 1MB chunks to stay well under message size limits
    const CHUNK_SIZE = 1024 * 1024
    let buffer = new Uint8Array(0)

    while (true) {
      const { done, value } = await reader.read()

      if (value) {
        // Append to buffer
        const newBuffer = new Uint8Array(buffer.length + value.length)
        newBuffer.set(buffer)
        newBuffer.set(value, buffer.length)
        buffer = newBuffer

        // Send chunks if we exceed CHUNK_SIZE
        while (buffer.length >= CHUNK_SIZE) {
          const chunk = buffer.slice(0, CHUNK_SIZE)
          buffer = buffer.slice(CHUNK_SIZE)
          port.postMessage({ type: 'chunk', data: Array.from(chunk) })
        }
      }

      if (done) {
        if (buffer.length > 0) {
          port.postMessage({ type: 'chunk', data: Array.from(buffer) })
        }
        port.postMessage({ type: 'end' })
        port.disconnect()
        break
      }
    }
  } catch (err) {
    port.postMessage({ error: err.message })
    port.disconnect()
  }
}

async function streamDropboxFile(url, port) {
  try {
    // Dropbox requires ?dl=1 to force direct download
    let downloadUrl = new URL(url)
    downloadUrl.searchParams.set('dl', '1')
    
    // fetch with credentials just in case it's a private link
    const res = await fetch(downloadUrl.toString(), { credentials: 'omit' })
    
    if (!res.ok) {
      port.postMessage({ error: `Failed to fetch from Dropbox: HTTP ${res.status}` })
      port.disconnect()
      return
    }

    const type = res.headers.get('content-type') || 'video/mp4'
    const nameMatch = downloadUrl.pathname.split('/').pop()
    const fileName = nameMatch ? nameMatch : 'dropbox-video.mp4'
    
    port.postMessage({ type: 'start', mimeType: type, name: fileName })

    const reader = res.body.getReader()
    const CHUNK_SIZE = 1024 * 1024
    let buffer = new Uint8Array(0)

    while (true) {
      const { done, value } = await reader.read()

      if (value) {
        const newBuffer = new Uint8Array(buffer.length + value.length)
        newBuffer.set(buffer)
        newBuffer.set(value, buffer.length)
        buffer = newBuffer

        while (buffer.length >= CHUNK_SIZE) {
          const chunk = buffer.slice(0, CHUNK_SIZE)
          buffer = buffer.slice(CHUNK_SIZE)
          port.postMessage({ type: 'chunk', data: Array.from(chunk) })
        }
      }

      if (done) {
        if (buffer.length > 0) {
          port.postMessage({ type: 'chunk', data: Array.from(buffer) })
        }
        port.postMessage({ type: 'end' })
        port.disconnect()
        break
      }
    }
  } catch (err) {
    port.postMessage({ error: err.message })
    port.disconnect()
  }
}
